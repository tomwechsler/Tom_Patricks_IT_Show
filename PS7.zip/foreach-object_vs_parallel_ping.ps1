$test = 'sid-500.com','orf.at','8.8.8.8','cnn.com'

### Foreach-Object -Parallel (7.0 or higher) Throttlelimit 5 default

If ($PSVersionTable.PSVersion.Major -gt '5') {

Measure-Command {$test | ForEach-Object -Parallel {Test-Connection -TargetName $_}} | 
Select-Object -Property @{n = 'Foreach-Object -Parallel'; e = {$_.Seconds}}

}

else {
throw 'This command requires PowerShell 7.0 or higher.'
}

### Foreach-Object PowerShell 5.1

Measure-Command  {$test | ForEach-Object {Test-Connection -TargetName $_}} | 
Select-Object -Property @{n = 'Foreach-Object'; e = {$_.Seconds}}


