# Installation of PowerShell 7.2.3 

# Download Powershell 7.2.3
Start-BitsTransfer `
-Source https://github.com/PowerShell/PowerShell/releases/download/v7.2.3/PowerShell-7.2.3-win-x64.msi `
-Destination (Join-Path -Path $home -ChildPath Downloads)

# Silent Installation
MsiExec.exe /i (Join-Path -Path $home -ChildPath Downloads\PowerShell-7.2.3-win-x64.msi) /qn